package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;


public interface ProductRepository extends JpaRepository <Product,Integer>{
     

	//SELECT p FROM Product p where p.price BETWEEN:low AND : HIGH 
	
}