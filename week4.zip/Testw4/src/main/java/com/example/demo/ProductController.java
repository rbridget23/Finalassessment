package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class ProductController {
     @Autowired
    private  ProductService productService;
	
     @GetMapping("/product")
	public List<Product> getProductDetails(){
		return productService.getProduct();
	}
	@PostMapping("/product")
		public String addProduct(@RequestBody Product product) {
		String result=productService.addProduct(product);
		return result;
	}
	@PutMapping("/product/{id}")
		public Product updateProductDetails(@PathVariable ("id") Integer id,@RequestBody Product product) {
		return productService.updateProduct(id,product);
		
	}
	@DeleteMapping("/product/{id}")
		public Product deleteProductdetails(@PathVariable("id")Integer id) {
		return productService.deleteProduct(id);
	}
	
	
}
