package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Product {
	@Id
    private int id;
    private String name;
    private Double price;
    
    
   Product(){
    }
   public Integer getId(int id) {
	   return id;
    }
   public void setId(Integer id) {
	   this.id=id;
   }
   public String getName(String id) {
	   return name;
    }
   public void setName(String name) {
	   this.name=name;
   }
   public Double getPrice(double price) {
	   return price;
    }
   public void setPrice(Double price) {
	   this.price=price;
   }	
}